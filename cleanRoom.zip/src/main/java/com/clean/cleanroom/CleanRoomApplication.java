package com.clean.cleanroom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CleanRoomApplication {

    public static void main(String[] args) {
        SpringApplication.run(CleanRoomApplication.class, args);
    }

}
