package com.clean.cleanroom.estimate.service;

public class EstimateRepository {
}
