package com.clean.cleanroom.estimate.dto;

public class EstimateResponseDto {
}
