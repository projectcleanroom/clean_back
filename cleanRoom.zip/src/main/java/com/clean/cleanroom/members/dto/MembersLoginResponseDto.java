package com.clean.cleanroom.members.dto;

public class MembersLoginResponseDto {
}
