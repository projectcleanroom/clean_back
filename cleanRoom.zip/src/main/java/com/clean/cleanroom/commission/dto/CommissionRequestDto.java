package com.clean.cleanroom.commission.dto;

public class CommissionRequestDto {
}
