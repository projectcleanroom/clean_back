package com.clean.cleanroom.enums;

public enum CleanType {
    일반, 특수
}
