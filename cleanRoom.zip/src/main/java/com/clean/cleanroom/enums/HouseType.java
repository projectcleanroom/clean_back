package com.clean.cleanroom.enums;

public enum HouseType {
//    원룸 O, 아파트 A, 주택 H, 화장실 T
    O, A, H, T
}
