package com.clean.cleanroom.pirtner.service;

public class PartnerService {
}
