package com.clean.cleanroom.pirtner.controller;

public class PartnerController {
}
