package com.clean.cleanroom.pirtner.repository;

import com.clean.cleanroom.pirtner.entity.Partner;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PartnerRepository extends JpaRepository<Partner, Long> {
}
