package com.clean.cleanroom.pirtner.dto;

public class PartnerRequestDto {
}
